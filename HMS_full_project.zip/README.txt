Hospital Management System - Full Project (Backend + Frontend)

Structure:
- backend/  -> Spring Boot backend (H2 in-memory DB)
- frontend/ -> Simple HTML/CSS/JS that calls backend APIs

How to run backend:
1. Open backend in IntelliJ or run from terminal
2. mvn spring-boot:run
3. Backend runs at http://localhost:8080
4. H2 console available at http://localhost:8080/h2-console
   - JDBC URL: jdbc:h2:mem:hospitaldb
   - User: sa
   - Password: (empty)

How to run frontend:
- Open frontend/index.html in your browser (double-click file) and use the forms.
- Or serve frontend folder with a static server; it's fine to open as file:///

Notes:
- This is a starter project. Add Spring Security, validation, hashing, DTOs, and file upload in future.
