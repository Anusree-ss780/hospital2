package com.hms.repository;
import com.hms.model.DischargeSummary;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface DischargeSummaryRepository extends JpaRepository<DischargeSummary, Long> {
    List<DischargeSummary> findByPatientId(Long patientId);
}