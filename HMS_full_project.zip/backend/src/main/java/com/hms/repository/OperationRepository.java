package com.hms.repository;
import com.hms.model.Operation;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface OperationRepository extends JpaRepository<Operation, Long> {
    List<Operation> findByPatientId(Long patientId);
}