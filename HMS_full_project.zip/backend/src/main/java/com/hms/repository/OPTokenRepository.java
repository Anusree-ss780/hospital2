package com.hms.repository;
import com.hms.model.OPToken;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface OPTokenRepository extends JpaRepository<OPToken, Long> {
    List<OPToken> findByStatus(String status);
}