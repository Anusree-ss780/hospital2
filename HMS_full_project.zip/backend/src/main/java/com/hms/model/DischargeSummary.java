package com.hms.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "discharge_summaries")
public class DischargeSummary {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    private Patient patient;
    @Column(length = 4000)
    private String summaryText;
    private LocalDate dischargeDate;
    public DischargeSummary(){}
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public Patient getPatient(){return patient;}
    public void setPatient(Patient patient){this.patient=patient;}
    public String getSummaryText(){return summaryText;}
    public void setSummaryText(String summaryText){this.summaryText=summaryText;}
    public LocalDate getDischargeDate(){return dischargeDate;}
    public void setDischargeDate(LocalDate dischargeDate){this.dischargeDate=dischargeDate;}
}
