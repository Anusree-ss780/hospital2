package com.hms.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "operations")
public class Operation {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    private Patient patient;
    private String status;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    @Column(length = 2000)
    private String notes;
    public Operation(){}
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public Patient getPatient(){return patient;}
    public void setPatient(Patient patient){this.patient=patient;}
    public String getStatus(){return status;}
    public void setStatus(String status){this.status=status;}
    public LocalDateTime getStartTime(){return startTime;}
    public void setStartTime(LocalDateTime startTime){this.startTime=startTime;}
    public LocalDateTime getEndTime(){return endTime;}
    public void setEndTime(LocalDateTime endTime){this.endTime=endTime;}
    public String getNotes(){return notes;}
    public void setNotes(String notes){this.notes=notes;}
}
