package com.hms.model;

import jakarta.persistence.*;

@Entity
@Table(name = "op_tokens")
public class OPToken {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Integer tokenNumber;
    private String status;
    @ManyToOne
    private Patient patient;
    public OPToken(){}
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public Integer getTokenNumber(){return tokenNumber;}
    public void setTokenNumber(Integer tokenNumber){this.tokenNumber=tokenNumber;}
    public String getStatus(){return status;}
    public void setStatus(String status){this.status=status;}
    public Patient getPatient(){return patient;}
    public void setPatient(Patient patient){this.patient=patient;}
}
