package com.hms.controller;

import com.hms.model.OPToken;
import com.hms.repository.OPTokenRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/op-tokens")
@CrossOrigin(origins = "*")
public class OPTokenController {
    private final OPTokenRepository repo;
    public OPTokenController(OPTokenRepository repo){ this.repo = repo; }

    @GetMapping
    public List<OPToken> all(){ return repo.findAll(); }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody OPToken t){
        OPToken saved = repo.save(t);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody OPToken incoming){
        return repo.findById(id).map(existing -> {
            existing.setStatus(incoming.getStatus());
            existing.setTokenNumber(incoming.getTokenNumber());
            OPToken updated = repo.save(existing);
            return ResponseEntity.ok(updated);
        }).orElse(ResponseEntity.notFound().build());
    }
}
