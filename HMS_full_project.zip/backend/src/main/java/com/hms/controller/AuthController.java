package com.hms.controller;

import com.hms.model.Patient;
import com.hms.model.Doctor;
import com.hms.repository.PatientRepository;
import com.hms.repository.DoctorRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    private final PatientRepository patientRepo;
    private final DoctorRepository doctorRepo;

    public AuthController(PatientRepository patientRepo, DoctorRepository doctorRepo) {
        this.patientRepo = patientRepo;
        this.doctorRepo = doctorRepo;
    }

    @PostMapping("/patient/register")
    public ResponseEntity<?> registerPatient(@RequestBody Patient p) {
        Optional<Patient> exists = patientRepo.findByEmail(p.getEmail());
        if (exists.isPresent()) return ResponseEntity.badRequest().body("Email already in use");
        Patient saved = patientRepo.save(p);
        return ResponseEntity.ok(saved);
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        String role = body.get("role");
        String email = body.get("email");
        String password = body.get("password");

        if ("patient".equalsIgnoreCase(role)) {
            Optional<Patient> p = patientRepo.findByEmail(email);
            if (p.isPresent() && p.get().getPassword().equals(password)) return ResponseEntity.ok(p.get());
        } else if ("doctor".equalsIgnoreCase(role)) {
            Optional<Doctor> d = doctorRepo.findByEmail(email);
            if (d.isPresent() && d.get().getPassword().equals(password)) return ResponseEntity.ok(d.get());
        }
        return ResponseEntity.status(401).body("Invalid credentials");
    }
}
