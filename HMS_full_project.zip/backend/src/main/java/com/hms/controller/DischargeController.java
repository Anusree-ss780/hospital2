package com.hms.controller;

import com.hms.model.DischargeSummary;
import com.hms.repository.DischargeSummaryRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/discharge")
@CrossOrigin(origins = "*")
public class DischargeController {
    private final DischargeSummaryRepository repo;
    public DischargeController(DischargeSummaryRepository repo){ this.repo = repo; }

    @GetMapping("/patient/{patientId}")
    public List<DischargeSummary> byPatient(@PathVariable Long patientId){
        return repo.findByPatientId(patientId);
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody DischargeSummary s){
        return ResponseEntity.ok(repo.save(s));
    }
}
