package com.hms.controller;

import com.hms.model.Operation;
import com.hms.repository.OperationRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/operations")
@CrossOrigin(origins = "*")
public class OperationController {
    private final OperationRepository repo;
    public OperationController(OperationRepository repo){ this.repo = repo; }

    @GetMapping
    public List<Operation> all(){ return repo.findAll(); }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Operation op){ return ResponseEntity.ok(repo.save(op)); }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Operation in){
        return repo.findById(id).map(existing -> {
            existing.setStatus(in.getStatus());
            existing.setStartTime(in.getStartTime());
            existing.setEndTime(in.getEndTime());
            existing.setNotes(in.getNotes());
            return ResponseEntity.ok(repo.save(existing));
        }).orElse(ResponseEntity.notFound().build());
    }
}
