document.getElementById('registerForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    name: document.getElementById('name').value,
    email: document.getElementById('email').value,
    password: document.getElementById('password').value,
    contact: document.getElementById('contact').value
  };
  const res = await fetch('http://localhost:8080/api/auth/patient/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const msgEl = document.getElementById('message');
  if(res.ok) {
    msgEl.innerText = 'Registered successfully!';
  } else {
    const text = await res.text();
    msgEl.innerText = 'Register failed: ' + text;
  }
});
